import RouteLinks from "./components/routes/RouteLinks";

function App() {
  return (
    <div className="App">
      <RouteLinks />
    </div>
  );
}

export default App;
