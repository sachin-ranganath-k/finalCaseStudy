export const GET_JOB_API="http://localhost:3001/jobs"
export const APPLY_JOB_API="http://localhost:3001/applyJobs"
export const CONTACT_US_API="http://localhost:3002/messages"