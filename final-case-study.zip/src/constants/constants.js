export const applyJobForm = {
  nameError: "Name should not be blank and should contain only letters",
  emailError: "Enter valid email",
  contactError: "Contact No. should be of 10 digits",
  experienceError: "Experience should contain min 10 and max 100 characters",
  getInTouchError: "Message should be of min 10 and max 100 characters",
};

export const patterns = {
  regName: /^[A-Za-z]+$/,
  regEmail: /[a-z0-9]+@[a-z]+\.[a-z]{2,3}/,
  regContact: /^\d{10}$/,
  regExperience: /^[A-Za-z\s]{10,100}$/,
};

export const successMsgs = {
  thankYouForContact:"Thank you for contacting us. You will get back to you shortly..!",
  thankYouApplyJob:"Congratulations..! You have applied for this job. Redirecting to jobs page..!"  
};

export const errorMsgs = {
  apiError: "Something went wrong..! Please try again later",
};
