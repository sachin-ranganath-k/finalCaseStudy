import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ApplyJob from "../ApplyJob";

import Jobs from "../Jobs";
import ApplyJobForm from "../ApplyJobForm"
import Navbar from "../Navbar/Navbar";
import ContactGetInTouch from "../ContactGetInTouch/ContactGetInTouch";
import Home from "../Home/Home";
import ViewMessages from "../ContactGetInTouch/ViewMessages";

const RouteLinks = () => {
  return (
    <div>
      <Router>
        <Navbar />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/jobs" element={<Jobs />} />
          <Route
            exact
            path="/applyJob/:id/:jobTitle/:jobLocation/:companyName"
            element={<ApplyJobForm />}
          />
           <Route exact path="/contact" element={<ContactGetInTouch />} />
           <Route exact path="/messages" element={<ViewMessages />} />
        </Routes>
      </Router>
    </div>
  );
};

export default RouteLinks;
