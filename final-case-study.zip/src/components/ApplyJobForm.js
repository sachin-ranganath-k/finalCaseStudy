import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import "../css/ApplyJobForm.css";
import {
  applyJobForm,
  errorMsgs,
  patterns,
  successMsgs,
} from "../constants/constants";
import { APPLY_JOB_API } from "../api/api";

const ApplyJobForm = () => {
  let { id, jobTitle, jobLocation, companyName } = useParams();
  const navigate = useNavigate();
  const [successMsg, setSuccessMsg] = useState(false);
  const [nameValidation, setNameValidation] = useState(false);
  const [emailValidation, setEmailValidation] = useState(false);
  const [experienceValidation, setExperienceValidation] = useState(false);
  const [contactValidtion, setContactValidation] = useState(false);
  const [applyJobApiError, setApplyJobApiError] = useState(false);

  const [formInputs, setFormInputs] = useState({
    applicantName: "",
    email: "",
    address: "",
    experience: "",
    contact: "",
  });

  const job_id = `JOB00${id}`;
  const jobId = id;

  const handleData = (e) => {
    const { name, value } = e.target;
    setFormInputs({
      ...formInputs,
      [name]: value,
    });
  };

  const appliedJobData = {
    ...formInputs,
    jobId,
    jobTitle,
    jobLocation,
    companyName,
  };
  const { applicantName, email, address, experience, contact } = formInputs;

  const submitData = () => {

    /* Apply Job from validation with pattern */

    if (applicantName === "" || !patterns.regName.test(applicantName)) {
      setNameValidation(true);
      setTimeout(() => {
        setNameValidation(false);
      }, 4000);
      return false;
    }
    if (email === "" || !patterns.regEmail.test(email)) {
      setEmailValidation(true);
      setTimeout(() => {
        setEmailValidation(false);
      }, 4000);
      return false;
    }
    if (experience === "" || !patterns.regExperience.test(experience)) {
      setExperienceValidation(true);
      setTimeout(() => {
        setExperienceValidation(false);
      }, 4000);
      return false;
    }

    if (contact === "" || !patterns.regContact.test(contact)) {
      setContactValidation(true);
      setTimeout(() => {
        setContactValidation(false);
      }, 4000);
      return false;
    }

    axios
      .post(`${APPLY_JOB_API}`, appliedJobData)
      .then((res) => {
        setSuccessMsg(true);
        setTimeout(() => {
          navigate("/jobs");
        }, 5000);
      })
      .catch((err) => {
        setApplyJobApiError(true);
      });
  };

  return (
    <div>
      <div class="testbox">
        <div className="form">
          <div class="banner">
            <h1>Apply For Job</h1>
          </div>
          <br />

          <div class="item">
            <label for="job_id">Job ID</label>
            <input id="job_id" type="text" value={job_id} disabled />
          </div>
          <div class="item">
            <label for="companyName">Company Name</label>
            <input
              id="companyName"
              type="text"
              name="companyName"
              value={companyName}
              onChange={handleData}
              disabled
            />
          </div>
          <div class="item">
            <label for="name">Job Title</label>
            <input
              id="name"
              type="text"
              name="name"
              value={jobTitle}
              onChange={handleData}
              disabled
            />
          </div>
          <div class="item">
            <label for="name">Job Location</label>
            <input
              id="location"
              type="text"
              name="location"
              value={jobLocation}
              onChange={handleData}
              disabled
            />
          </div>
          <div class="item">
            <label for="name">Enter Name</label>
            <span>*</span>
            <input
              id="applicantName"
              type="text"
              name="applicantName"
              value={applicantName}
              onChange={handleData}
              required
            />
            <p style={{ color: "red", fontSize: "15px" }}>
              {nameValidation && applyJobForm.nameError}
            </p>
          </div>
          <div class="item">
            <label for="email">
              Enter Email ID<span>*</span>
            </label>
            <input
              id="email"
              type="email"
              name="email"
              value={email}
              onChange={handleData}
              required
            />
            <p style={{ color: "red", fontSize: "15px" }}>
              {emailValidation && applyJobForm.emailError}
            </p>
          </div>
          <div class="item">
            <label for="address">Enter Address (Optional)</label>
            <input
              id="address"
              type="address"
              name="address"
              value={address}
              onChange={handleData}
              required
            />
          </div>
          <div class="item">
            <label for="city">
              Enter Experience<span>*</span>
            </label>
            <textarea
              id="experience"
              name="experience"
              value={experience}
              onChange={handleData}
            />
            <p style={{ color: "red", fontSize: "15px" }}>
              {experienceValidation && applyJobForm.experienceError}
            </p>
          </div>

          <div class="item">
            <label for="phone">
              Enter Contact No.<span>*</span>
            </label>
            <input
              id="contact"
              type="text"
              name="contact"
              value={contact}
              onChange={handleData}
              required
            />
            <p style={{ color: "red", fontSize: "15px" }}>
              {contactValidtion && applyJobForm.contactError}
            </p>
          </div>
          {successMsg && (
            <div
              className="alert alert-success item"
              style={{ lineHeight: "20px" }}
            >
              <strong>{successMsgs.thankYouApplyJob}</strong>
            </div>
          )}
          {applyJobApiError && (
            <div
              className="alert alert-danger item"
              style={{ lineHeight: "20px" }}
            >
              <strong>{errorMsgs.apiError}</strong>
            </div>
          )}
          <div
            style={{ textAlign: "center", fontWeight: "bold", padding: "5px" }}
          >
            <button
              className="btn btn-warning"
              style={{ padding: "15px" }}
              onClick={submitData}
            >
              APPLY
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplyJobForm;
