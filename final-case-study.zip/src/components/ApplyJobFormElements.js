import React, {useState} from "react";
import { useParams } from "react-router-dom";
import ApplyJobForm from "./ApplyJobForm";

const ApplyJobFormElements = () => {
    const { id, jobTitle, jobLocation, companyName } = useParams();
  const formElements = [
    {
      label: "Company Name",
      id: "companyName",
      name: "companyName",
      value: companyName,
      disabled: true,
    },
    {
      label: "Job Title",
      id: "jobTitle",
      name: "jobTitle",
      value: jobTitle,
      disabled: true,
    },
    {
      label: "Job Location",
      id: "jobLocation",
      name: "jobLocation",
      value: jobLocation,
      disabled: true,
    },
    {
      label: "Enter Name",
      id: "applicantName",
      type: "text",
      name: "applicantName",
      value: applicantName,
      required: true,
      pattern: "[A-Za-z]+",
      title:
        "Name should not contain any special characters or numbers or space",
    },
    {
      label: "Enter Email",
      id: "email",
      type: "email",
      name: "email",
      value: email,
      required: true,
    },
    {
      label: "Enter Address",
      id: "address",
      type: "text",
      name: "address",
      value: address,
      required: true,
    },
    {
      label: "Enter Contact No",
      id: "contact",
      type: "text",
      name: "contact",
      value: contact,
      required: true,
    },
    {
      label: "Experience (In Years)",
      id: "experience",
      type: "number",
      name: "experience",
      value: experience,
      required: true,
      step: 0.1,
    },
  ];
  const [formInputs, setFormInputs] = useState({
    applicantName: "",
    email: "",
    address: "",
    experience: "",
    contact: "",
  });

  const handleData = (e) => {
    const { name, value } = e.target;
    setFormInputs({
      ...formInputs,
      [name]: value,
    });
  };

  const { applicantName, email, address, experience, contact } = formInputs;
  return (
    <div>
      <ApplyJobForm formElements={formElements} handleData={handleData} />
    </div>
  );
};

export default ApplyJobFormElements;
