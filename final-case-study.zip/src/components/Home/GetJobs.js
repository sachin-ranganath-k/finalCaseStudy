import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { getJobs, showApiError } from "../../redux/actions/actions";
import { GET_JOB_API } from "../../api/api";
import Loading from "../Loader/Loader";
import ApiError from "../ApiError";

const GetJobs = () => {
  const dispatch = useDispatch();

  /*
  Based on getJobs()  action, the jobs will be stored in the store and 
  fetched here using useSelector()
  */
  const allJobs = useSelector((state) => state.allJobs);
  const showApiErrorMsg = useSelector((state) => state.showApiError);

  const [loading, setLoading] = useState(false);

/*
  getJobsApi() will be called first once component renders.
*/
  useEffect(() => {
    getJobsApi();
  }, []);

  /*
    getJobsApi function, in which API called with limit=8. 
    Only 8 jobs will be called and dispatched with getJobs() action
  */
  const getJobsApi = async () => {
    setLoading(true);
    await axios
      .get(`${GET_JOB_API}?_limit=8`)
      .then((res) => {
        console.log(res);
        dispatch(getJobs(res.data));
        setLoading(false);
      })
      .catch((err) => {
        setLoading(false);
        dispatch(showApiError(true));
      });
  };

  return (
    <div>
      <section className="news section-padding">
        <div className="container">
          <p
            className="text-center mb-lg-5 mb-4"
            style={{ fontSize: "40px", fontWeight: "bold" }}
          >
            Top Jobs
          </p>
          <br />
          {showApiErrorMsg ? (
            <ApiError />
          ) : (
            <div className="row">
              {allJobs.map((job) => (
                <div className="col-lg-3 col-md-3 col-12">
                  <div className="news-thumb mb-4">
                    <div className="card" style={{ borderRadius: "6%" }}>
                      <div className="card-body">
                        <p
                          style={{
                            color: "#4a90e2",
                            fontSize: "14px",
                            fontWeight: "bold",
                            lineHeight: "20px",
                          }}
                        >
                          {job.jobTitle}
                        </p>

                        <p
                          style={{
                            color: "#4a90e2",
                            fontSize: "12px",
                            lineHeight: "25px",
                          }}
                        >
                          {job.companyName}
                        </p>
                        <p style={{ color: "#4a90e2", fontSize: "10px" }}>
                          <span className="glyphicon glyphicon-briefcase"></span>
                          &nbsp;
                          {job.minExperience}-{job.maxExperience} Yrs
                          &nbsp;&nbsp;
                          <i className="fa fa-inr"></i>&nbsp;{job.minSalary}-
                          {job.maxSalary}
                          &nbsp;&nbsp;&nbsp;
                          <span className="glyphicon glyphicon-map-marker"></span>
                          &nbsp;{job.location}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <div align="center"> {loading ? <Loading /> : <></>} </div>
    </div>
  );
};

export default GetJobs;
