import React from "react";
import Carousel from "react-bootstrap/Carousel";
import img1 from "../../images/carousel-images/3.jpg";
import img2 from "../../images/carousel-images/4.jpg";
import img3 from "../../images/carousel-images/5.jpg";

const CarouselSlider = () => {
  return (
    <Carousel variant="dark">
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={img1}
          alt="First slide"
          height={400}
          width={500}
        />
        <Carousel.Caption>
        <p style={{ color: "black", fontSize: "50px" }}>Looking your dream job..?</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={img2}
          alt="Second slide"
          height={400}
          width={500}
        />
        <Carousel.Caption>
        <p style={{ color: "black", fontSize: "50px" }}>No. of opportunities that you won't expect</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={img3}
          alt="Third slide"
          height={400}
          width={500}
        />
        <Carousel.Caption>
          <p style={{ color: "black", fontSize: "50px" }}>Easy Apply</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
};

export default CarouselSlider;
