import React from "react";
import Footer from "../Footer";
import CarouselSlider from "./Carousel";
import GetJobs from "./GetJobs";

const Home = () => {
  return (
    <>
      <CarouselSlider />
      <GetJobs />
      <Footer />
    </>
  );
};

export default Home;
