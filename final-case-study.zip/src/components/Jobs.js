import React from "react";
import GetAllJobs from "./AllJobs";
import Footer from "./Footer";

const Jobs = () => {
  return (
    <div>
      <GetAllJobs />
      <Footer />
    </div>
  );
};

export default Jobs;
