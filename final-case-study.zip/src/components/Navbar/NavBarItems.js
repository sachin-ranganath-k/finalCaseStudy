export const navBarItems = [
    {
      elementName: "Home",
      path: "/",
    },
    {
      elementName: "Jobs",
      path: "/jobs",
    },
    {
      elementName: "Contact Us",
      path: "/contact",
    },
  ];