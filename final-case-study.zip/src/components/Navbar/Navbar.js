import React from "react";
import { Link } from "react-router-dom";
import { navBarItems } from "./NavBarItems";

const Navbar = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <p>
          <Link
            className="navbar-brand me-2"
            to="/"
            style={{ fontWeight: "bold", fontSize: "25px" }}
            data-testid="topJobs"
          >
            Top Jobs
          </Link>
        </p>

        <div className="collapse navbar-collapse" id="navbarButtonsExample">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <a className="nav-link" href="#"></a>
            </li>
          </ul>

          <div className="d-flex align-items-center">
            {/* NavBar items come from navBarItems array */}
            {navBarItems.map((element, index) => (
              <div key={index}>
                <Link
                  to={element.path}
                  style={{
                    textDecoration: "none",
                    fontSize: "16px",
                    color: "black",
                    fontWeight: "bold",
                  }}
                >
                  {element.elementName}
                </Link>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                {/* <button
                  type="button"
                  className="btn px-5 me-5"
                  onClick={() => navigate(element.path)}
                >
                  {element.elementName}
                </button> */}
              </div>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
