import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { navBarItems } from "./NavBarItems";

const Navbar = () => {
  const navigate = useNavigate();
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <p>
          <Link
            className="navbar-brand me-2"
            to="/"
            style={{ fontWeight: "bold", fontSize: "25px" }}
          >
            Top Jobs
          </Link>
        </p>

        <div className="collapse navbar-collapse" id="navbarButtonsExample">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <a className="nav-link" href="#"></a>
            </li>
          </ul>

          <div className="d-flex align-items-center">
            {navBarItems.map((element, index) => (
              <div key={index}>
                <button
                  type="button"
                  className="btn px-5 me-5"
                  onClick={() => navigate(element.path)}
                >
                  {element.elementName}
                </button>
              </div>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
