import React from "react";

const ApiError = () => {
  return (
    <div>
      <div className="alert alert-danger">
        <div align="center" style={{fontSize:"15px"}} data-testid="errorApi">
           Something went wrong while fetching jobs..!
        </div>
      </div>
    </div>
  );
};

export default ApiError;
