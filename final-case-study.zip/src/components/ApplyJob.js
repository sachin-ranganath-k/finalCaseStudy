import React from "react";
import ApplyJobForm from "./ApplyJobForm";
import Footer from "./Footer";
import Navbar from "./Navbar/Navbar";

const ApplyJob = () => {

  return (
    <>
      <Navbar />
      <ApplyJobForm />
      <Footer />
    </>
  );
};

export default ApplyJob;
