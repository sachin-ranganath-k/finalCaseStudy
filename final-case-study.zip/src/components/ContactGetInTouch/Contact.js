import React from "react";
import "../../bootstrap/bootstrap/css/bootstrap.min.css";
import "../../bootstrap/bootstrap-icons/bootstrap-icons.css";
import "../../bootstrap/glightbox/css/glightbox.min.css";

const Contact = () => {
  return (
    <>
      <div className="section-title">
        <h2 align="center">
          <span>Contact Us</span>
        </h2>
      </div>
      <div className="container">
        <br />

        <div className="info-wrap">
          <div className="col-md-12">
            <div className="row">
              <div className="col-md-6 info">
              <span className="glyphicon glyphicon-phone"></span>
                <h4>Phone</h4>
                <p>080-225588</p>
              </div>

              <div className="col-md-6">
                 <span className="glyphicon glyphicon-envelope"></span>
                <h4>Email</h4>
                <p>contact@topjobs.com</p>
              </div>
            </div>
          </div>
          <div className="col-md-12" style={{ marginTop: "8%" }}>
            <div className="row">
              <div className="col-md-6 info">
              <span className="glyphicon glyphicon-home"></span>
                <h4>Address</h4>
                <p>
                  Hebbal Outer Ring Road
                  <br />
                  Bengaluru,
                  <br />
                  Karnataka
                </p>
              </div>

              <div className="col-md-6">
                <i className="bi bi-geo-alt"></i>
                <h4>Locate Us</h4>
                <p>
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3653.988076469744!2d77.6221383!3d13.0489942!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae17659e5aeccb%3A0x2eecadc5e9e8dbab!2sCognizant%20Technology%20Solutions!5e1!3m2!1sen!2sin!4v1671520432175!5m2!1sen!2sin"
                    width="300"
                    height="300"
                    style={{ border: "0" }}
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                  ></iframe>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
