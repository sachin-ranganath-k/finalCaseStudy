import React from "react";
import Footer from "../Footer";
import Contact from "./Contact";
import GetInTouch from "./GetInTouch";

const ContactGetInTouch = () => {
  return (
    <>
     <div className="container">
        <div className="row">
          <div className="col-md-6">
            <GetInTouch />
            
          </div>
          <div className="col-md-6">
            <Contact />
          </div>
        </div>
        <br />
        <br />
        </div>
      <Footer />
    </>
  );
};

export default ContactGetInTouch;
