import axios from "axios";
import React, { useEffect, useState } from "react";
import { CONTACT_US_API } from "../../api/api";

const ViewMessages = () => {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = () => {
    axios
      .get(`${CONTACT_US_API}`)
      .then((res) => {
        setMessages(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div className="container">
      <table className="table table-hover">
        <thead>
          <tr>
            <th>Sl No.</th>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Message</th>
          </tr>
        </thead>
        <tbody>
          {messages.map((msg, index) => (
            <tr>
              <td>{index + 1}</td>
              <td>{msg?.name}</td>
              <td>{msg?.email}</td>
              <td>{msg?.contact}</td>
              <td>{msg?.message}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewMessages;
