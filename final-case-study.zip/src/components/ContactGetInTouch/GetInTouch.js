import React, { useState } from "react";
import "../../bootstrap/bootstrap/css/bootstrap.min.css";
import "../../bootstrap/bootstrap-icons/bootstrap-icons.css";
import "../../bootstrap/glightbox/css/glightbox.min.css";
import {
  applyJobForm,
  errorMsgs,
  patterns,
  successMsgs,
} from "../../constants/constants";
import axios from "axios";
import { showApiError } from "../../redux/actions/actions";
import { useDispatch, useSelector } from "react-redux";
import { CONTACT_US_API } from "../../api/api";

const GetInTouch = () => {
  const [successMsg, setSuccessMsg] = useState(false);
  const [nameValidation, setNameValidation] = useState(false);
  const [emailValidation, setEmailValidation] = useState(false);
  const [msgValidation, setMsgValidation] = useState(false);
  const [contactValidtion, setContactValidation] = useState(false);
  const [inputData, setInputData] = useState({
    name: "",
    email: "",
    contact: "",
    message: "",
  });
  const dispatch = useDispatch();
  const apiError = useSelector((state) => state.showApiError);

  const handleInputs = (e) => {
    const { name, value } = e.target;
    setInputData({
      ...inputData,
      [name]: value,
    });
  };

  //inputFields Object destructured
  let { name, email, contact, message } = inputData;

// All the textboxes will become empty once submitted the form
  const resetFields = () => {
    inputData.name = "";
    inputData.email = "";
    inputData.contact = "";
    inputData.message = "";
  };

  /* Validation to check empty fields and with pattern */
  const submitMsg = () => {
    if (name === "" || !patterns.regName.test(name)) {
      setNameValidation(true);
      setTimeout(() => {
        setNameValidation(false);
      }, 4000);
      return false;
    }
    if (email === "" || !patterns.regEmail.test(email)) {
      setEmailValidation(true);
      setTimeout(() => {
        setEmailValidation(false);
      }, 4000);
      return false;
    }

    if (contact === "" || !patterns.regContact.test(contact)) {
      setContactValidation(true);
      setTimeout(() => {
        setContactValidation(false);
      }, 4000);
      return false;
    }

    if (message === "" || !patterns.regExperience.test(message)) {
      setMsgValidation(true);
      setTimeout(() => {
        setMsgValidation(false);
      }, 4000);
      return false;
    }

// API call to post the Contact Us form.

    axios
      .post(`${CONTACT_US_API}`, inputData)
      .then((res) => {
        setSuccessMsg(true);
        resetFields();
        setTimeout(() => {
          setSuccessMsg(false);
        }, 4000);
      })
      .catch((err) => {
        dispatch(showApiError(true));
        setTimeout(() => {
          dispatch(showApiError(false));
        }, 4000);
      });
  };

  return (
    <div classNameName="container">
      <section id="contact" className="contact">
        <div className="container">
          <div className="section-title">
            <h2 align="center">
              <span>Get in touch</span>
            </h2>
          </div>
        </div>
        {successMsg && (
          <div className="alert alert-success" style={{ lineHeight: "20px" }}>
            <strong>{successMsgs.thankYouForContact}</strong>
          </div>
        )}
        {apiError && (
          <div className="alert alert-danger" style={{ lineHeight: "20px" }}>
            <strong>{errorMsgs.apiError}</strong>
          </div>
        )}
        <div className="container mt-5">
          <div className="form-group mt-3">
            <input
              type="text"
              name="name"
              className="form-control"
              id="name"
              value={name}
              placeholder="Your Name"
              onChange={handleInputs}
            />
            <p style={{ color: "red", fontSize: "10px", fontWeight: "bold" }}>
              {nameValidation && applyJobForm.nameError}
            </p>
          </div>
          <div className="form-group mt-3">
            <input
              type="email"
              className="form-control"
              name="email"
              id="email"
              value={email}
              placeholder="Your Email"
              onChange={handleInputs}
            />
            <p style={{ color: "red", fontSize: "10px", fontWeight: "bold" }}>
              {emailValidation && applyJobForm.emailError}
            </p>
          </div>

          <div className="form-group mt-3">
            <input
              type="text"
              className="form-control"
              name="contact"
              id="contact"
              value={contact}
              placeholder="Your Contact No"
              onChange={handleInputs}
            />
            <p style={{ color: "red", fontSize: "10px", fontWeight: "bold" }}>
              {contactValidtion && applyJobForm.contactError}
            </p>
          </div>
          <div className="form-group mt-3">
            <textarea
              className="form-control"
              name="message"
              rows="5"
              placeholder="Message"
              value={message}
              onChange={handleInputs}
            ></textarea>
            <p style={{ color: "red", fontSize: "10px", fontWeight: "bold" }}>
              {msgValidation && applyJobForm.getInTouchError}
            </p>
          </div>

          <button className="btn btn-primary" onClick={submitMsg}>
            Send Message
          </button>
        </div>
      </section>
    </div>
  );
};

export default GetInTouch;
