import { render, screen } from "@testing-library/react";
import CarouselSlider from "../Home/Carousel";

describe("Corousal Slider Component", () => {
  it("Render CarouselSlider coponent", () => {
    render(<CarouselSlider />);
  });

  it("Find Top Jobs text", () => {
    render(<CarouselSlider />);
    const easyApplyText = screen.getByTestId("easyApply");
    expect(easyApplyText.textContent).toBe("Easy Apply");
  });
});
