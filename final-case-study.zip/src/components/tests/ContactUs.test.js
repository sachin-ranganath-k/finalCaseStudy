import { render, screen } from "@testing-library/react";
import Contact from "../ContactGetInTouch/Contact";

describe("Contact us", () => {
  it("Render contact us component", () => {
    render(<Contact />);
  });

  it("Find Top Jobs text", () => {
    render(<Contact />);
    const contactUs = screen.getByTestId("contactUs");
    expect(contactUs.textContent).toBe('Contact Us')
  });
});
