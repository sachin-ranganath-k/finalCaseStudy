import { render, screen } from "@testing-library/react";
import ApiError from "../ApiError";

describe("Api Error Component", () => {
  it("Render ApiError coponent", () => {
    render(<ApiError />);
  });

  it("Find  text", () => {
    render(<ApiError />);
    const apiError = screen.getByTestId("errorApi");
    expect(apiError.textContent).toBe(
      "Something went wrong while fetching jobs..!"
    );
  });
});
