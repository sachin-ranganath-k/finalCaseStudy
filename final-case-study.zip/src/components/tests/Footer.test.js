import { render, screen } from "@testing-library/react";
import Footer from "../Footer";

describe("Contact us", () => {
  it("Render footer component", () => {
    render(<Footer />);
  });

  it("Find Social Media text", () => {
    render(<Footer />);
    const socialMedia = screen.getByTestId("socialMedia");
    expect(socialMedia.textContent).toBe("Social Media");
  });
});
