import { render, screen } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import Navbar from "../Navbar/Navbar";

describe("Navbar component", () => {
  it("Render navbar component", () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
  });

  it("Find Top Jobs text", () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const topJobsText = screen.getByTestId("topJobs");
    expect(topJobsText).toBeInTheDocument();
  });
});
