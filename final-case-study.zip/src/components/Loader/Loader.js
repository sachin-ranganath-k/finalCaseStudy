import React from "react";

const Loading = () => {
  return (
    <>
      <div
        className="spinner-grow"
        style={{ width: "2rem", height: "2rem" }}
        role="status"
      />
      <div
        className="spinner-grow"
        style={{ width: "2rem", height: "2rem" }}
        role="status"
      />
      <div
        className="spinner-grow"
        style={{ width: "2rem", height: "2rem" }}
        role="status"
      />
    </>
  );
};

export default Loading;
