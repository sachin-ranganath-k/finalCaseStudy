export const GET_JOBS="GET_JOBS"
export const SHOW_API_ERROR="SHOW_API_ERROR"