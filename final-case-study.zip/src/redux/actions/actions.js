import { GET_JOBS, SHOW_API_ERROR } from "./actionConstants";

export const getJobs = (payload) => {
  return {
    type: GET_JOBS,
    payload
  };
};

export const showApiError=(status)=>{
    return{
        type:SHOW_API_ERROR,
        payload:status
    }
}
