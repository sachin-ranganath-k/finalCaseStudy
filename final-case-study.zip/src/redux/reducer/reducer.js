import * as actionTypes from "../actions/actionConstants";

const initialState = {
  allJobs: [],
  showApiError: false,
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.GET_JOBS:
      return {
        ...state,
        allJobs: action.payload,
      };

    case actionTypes.SHOW_API_ERROR:
      return {
        ...state,
        showApiError: action.payload,
      };
    default:
      return state;
  }
};

export default reducer;
